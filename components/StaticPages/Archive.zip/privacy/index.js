import React from "react";


export default class About extends React.Component {
  componentDidMount = () => {
    
  };

  render() {
    return (
      <>
		<div class="col-md-8">
			<h1>Terms of Service - Stylicle</h1>
			<p>Morbi mollis interdum eros, non accumsan magna elementum sit amet.</p>
			<p class="text-uppercase"><strong>Vivamus euismod massa nec nunc auctor egestas. Praesent sed pulvinar enim. Maecenas magna diam, vulputate at dolor vel, cursus imperdiet sem. Phasellus imperdiet mi non justo sollicitudin rhoncus. </strong></p>
			<h1>Part I – Definitions, Agreement to be Bound.</h1>
			<div class="pl-3 pr-3">
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<ol>
					<li>Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat.</li>
					<li>Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat.</li>
					<li>Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat.</li>
					<li>Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat.</li>
					<li>Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat.</li>
				</ol>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
				<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
			</div>
		</div>
      </>
    );
  }
}
