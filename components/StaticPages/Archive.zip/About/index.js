import React from "react";


export default class About extends React.Component {
  componentDidMount = () => {
    
  };

  render() {
    return (
      <>
        <div class="col-md-8">
            <h1>About Us - Stylicle</h1>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. Etiam cursus, dui quis fringilla aliquam, odio sapien accumsan lorem, scelerisque egestas nisl dolor quis ligula. Donec et enim ex. Curabitur lacinia euismod rhoncus. Integer interdum purus in dignissim fringilla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque vulputate eu risus iaculis dapibus. Fusce vehicula auctor maximus. Phasellus eu interdum orci, a iaculis elit. Praesent iaculis metus id ex lobortis viverra. Nam imperdiet felis id tempus tristique. </p>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
            <div>
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
            </div>
            </div>
            <h1>Get to know us</h1>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
            <h1>What people say</h1>
            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent vel urna venenatis, semper odio at, viverra nisi. Quisque lobortis nunc ut nibh lacinia consequat. </p>
            <blockquote>
            Phasellus sagittis orci eget pellentesque placerat. Integer ac ex vitae nisi lobortis tristique quis ac sem. Integer rhoncus mauris sit amet ligula lacinia, vitae facilisis enim porta. Vestibulum consectetur volutpat aliquam. 
            </blockquote>
            <small>@hairstyle, Jhondoe, NJ </small>
            <blockquote>
            Phasellus sagittis orci eget pellentesque placerat. Integer ac ex vitae nisi lobortis tristique quis ac sem. Integer rhoncus mauris sit amet ligula lacinia, vitae facilisis enim porta. Vestibulum consectetur volutpat aliquam. 
            </blockquote>
            <small>@hairstyle, Jhondoe, NJ </small>
            <h1>How Booksy works</h1>
            <p>Duis interdum elit non leo viverra sollicitudin. Nam sed enim eros. Curabitur porttitor, ligula sed cursus pellentesque, leo felis vestibulum leo,</p>
            <p><strong>Find services you will love</strong><br/>Duis interdum elit non leo viverra sollicitudin. Nam sed enim eros. Curabitur porttitor, ligula sed cursus pellentesque, leo felis vestibulum leo,</p>
            <p><strong>Book appointments 24/7</strong><br/>Duis interdum elit non leo viverra sollicitudin. Nam sed enim eros. Curabitur porttitor, ligula sed cursus pellentesque, leo felis vestibulum leo,</p>
            <p><strong>Share your experience</strong><br/>Duis interdum elit non leo viverra sollicitudin. Nam sed enim eros. Curabitur porttitor, ligula sed cursus pellentesque, leo felis vestibulum leo,</p>
        </div>
      </>
    );
  }
}
